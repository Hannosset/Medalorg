﻿using System.Windows.Forms;

namespace mui
{
	public partial class AddItem : Form
	{
		public AddItem()
		{
			InitializeComponent();
		}
	}
}
